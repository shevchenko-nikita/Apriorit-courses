// app.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "WordsProcessingApi.h"

//Test data
//Unit testing is a level of software testing where individual units of a software are tested.
int main()
{
    std::cout << "Enter text for counting words, please:\n";
    std::string line;
    std::getline(std::cin, line);
    
    const auto words = api::CountWordsOccurrences(line);

    for (const auto& word: words)
    {
        std::cout << word.first << " " << word.second << std::endl;
    }

    return 0;
}

