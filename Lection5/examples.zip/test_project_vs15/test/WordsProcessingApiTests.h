#pragma once

namespace tests
{
    void CheckWordsProcessingApi();
}