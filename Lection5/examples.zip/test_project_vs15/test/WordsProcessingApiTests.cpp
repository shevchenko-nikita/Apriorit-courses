#include "stdafx.h"
#include "WordsProcessingApi.h"
#include "WordsProcessingApiTests.h"

void tests::CheckWordsProcessingApi()
{
    api::WordsCount expected1 = {
        { "one", 2 },
        { "two", 1 }
    };
    if (expected1 != api::CountWordsOccurrences("one two one"))
    {
        throw std::exception("CountWordsOccurrences does not increment occurrences count");
    }

    api::WordsCount expected2 = {
        { "one", 1 },
        { "two", 1 }
    };
    if (expected2 != api::CountWordsOccurrences("one       two"))
    {
        throw std::exception("CountWordsOccurrences process many spaces as words");
    }
}
