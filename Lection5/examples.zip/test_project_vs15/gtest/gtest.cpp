// gtest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
