#include "stdafx.h"

class HttpRequest
{
public:
    virtual std::string Get(const std::string& url)
    {
        return "response body";
    }
};
struct AuthResult
{
    std::string token;
    std::string userId;
};

AuthResult Login(const std::string& email, const std::string& password, HttpRequest& request)
{
    const auto response = request.Get("https://mysite.com/login?user=" + email + "&pw=" + password);
    return {/*ParseAuthResponse(response)*/};
}

class MockHttpRequest : public HttpRequest
{
public:
    MOCK_METHOD1(Get, std::string(const std::string&));
};

TEST(LoginUtils, Login_RequestsDataByCorrectUrl)
{
    MockHttpRequest request;
    EXPECT_CALL(request, Get("https://mysite.com/login?user=vlad&pw=pass"));
    Login("vlad", "pass", request);
}