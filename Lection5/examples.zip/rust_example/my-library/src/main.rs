mod lib;

fn main() {
	let msg = format!("{}{}", "Sum: ", lib::add(1, 2));
    println!("{}", msg);
}
