1. install rust
2. run "cargo test" from my-library directory